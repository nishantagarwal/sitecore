This package installs Media Library Minifier module which minifies JS and CSS files present in media library on publishing.

For more details visit Sitecore Market Place:
http://marketplace.sitecore.net/en/Modules/Sitecore_Media_Lib_Minifier.aspx