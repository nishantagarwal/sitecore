This package installs Media Items Minifier module. 
It uses YUICompressor to minify CSS/JS media items on publish in target environment.

For more info visit http://www.agarwalnishant.com/2013/06/sitecore-cssjs-media-items-minfier.html